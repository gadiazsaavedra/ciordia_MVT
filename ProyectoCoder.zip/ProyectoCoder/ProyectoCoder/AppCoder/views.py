from multiprocessing import context
from re import template
from django.shortcuts import render

# Create your views here.
from django.template import Context, Template
from django.http import HttpResponse

import random



def Saludo_con_template(request):
    mi_archivo= open("D:\CODER\ProyectoCoder\ProyectoCoder\ProyectoCoder\templates\templates1.html")
    template= Template(mi_archivo.read())
    mi_archivo.close()
    
    context= Context()
    
    res= template.render(context)
    return HttpResponse(res)



'''
def crear_profesor(request):
    profe= Profesor(nombre="Ricardo", apellido="Ruben", email="ric@coder.com", profesion="Tecnico electronico")
    
    return HttpResponse(f"Estoy creando un profesor: {profe.nombre} {profe.apellido}. Su profesion es: {profe.profesion}")
'''