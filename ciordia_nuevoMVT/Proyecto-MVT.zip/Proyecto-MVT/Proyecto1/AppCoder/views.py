from re import template
from django.http import HttpResponse
from django.shortcuts import render

from django.template import loader

# Create your views here.

from AppCoder.models import Familia


def crear_familiar(request):
    
    template= loader.get_template("template1.html")
    
    flia= Familia(nombre="Paula", parentezco="Sobrina", edad="15")
    flia_2= Familia(nombre="Sofia", parentezco="prima", edad="20")
    flia_3= Familia(nombre="Florencia", parentezco="ahijada", edad="29")
    
    dict_de_contexto= {
    "flia": flia.nombre,
    "flia_2": flia_2.nombre,
    "flia_3": flia_3.nombre,
    }
    
    res= template.render(dict_de_contexto)
    
    return HttpResponse(res)
    
